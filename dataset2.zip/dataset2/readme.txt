  Name                     Size                 Bytes  Class     Attributes

  DDI_binary             568x568              2580992  double              binary DDI matrix
  DDI_triple             568x568              2580992  double              comprehensive DDI matrix
  offsides_feature       568x9149            41573056  double              side effects
  pca_offisides          568x557              2531008  double              after kernel PCA (16)
  pca_structure          568x487              2212928  double              after kernel PCA (4)
  structure_feature      568x881              4003264  double              chemical structure descriptor